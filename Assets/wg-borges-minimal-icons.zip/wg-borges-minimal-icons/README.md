# Minimal Icons
# Free Ever Growing Collection of 100+ Minimal Icons for Designers and Developers.

<img src="Preview.png?raw=true" alt="Preview Image" width="396" height="396">

Minimal Icons is a free icon set, it works perfectly for your apps or web projects. You may use these icons for both commercial and personal projects.

The download includes:
* PNG
* SVG
* PDF
* Sketch File
